// document.addEventListener("DOMContentLoaded",function(){
//     console.log("In new_listing.js file");
// })
console.log(
    "Hello from new_listing.js"
)